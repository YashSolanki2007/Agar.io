import pygame
import time
import math
import random 

#Game Variables
WIDTH = 800
HEIGHT = 600
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
player1_X = 15
player1_Y = 300
player1_radius = 20
player1_X_change = 0
player1_Y_change = 0
player2_X = 780
player2_Y = 300
player2_radius = 20
player2_X_change = 0
player2_Y_change = 0
blob1_X = random.randint(5, 795)
blob1_Y = random.randint(5, 595)
blob1_radius = 5
blob2_X = random.randint(5, 795)
blob2_Y = random.randint(5, 595)
blob2_radius = 5
blob3_X = random.randint(5, 795)
blob3_Y = random.randint(5, 595)
blob3_radius = 5
blob4_X = random.randint(5, 795)
blob4_Y = random.randint(5, 595)
blob4_radius = 5
blob5_X = random.randint(5, 795)
blob5_Y = random.randint(5, 595)
blob5_radius = 5
GREEN = (0, 255, 0)

#Initialize pygame
pygame.init()

#Make the screen 
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Agar.Io Replica")

#Make the display icon 
icon = pygame.image.load("game.png")
pygame.display.set_icon(icon)

#Player1 score
player1_score_value = 0
font = pygame.font.Font('freesansbold.ttf',32)
textX = 10
textY = 10

#Player2 score
player2_score_value = 0
font = pygame.font.Font('freesansbold.ttf',32)
textX_2 = 570
textY_2 = 10

#Functions 
def show_score(x,y):
	score = font.render("Red Score :" + str(player1_score_value),True,(0, 0, 0))
	screen.blit(score,(x,y))

def show_score_2(x,y):
	score = font.render("Blue Score :" + str(player2_score_value),True,(0, 0, 0))
	screen.blit(score,(x,y))

def isCollision_between_players(player1_X, player1_Y, player2_X, player2_Y):
	distance = math.sqrt((math.pow(player1_X - player2_X, 2) + math.pow(player1_Y - player2_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player1_and_blob1(player1_X, player1_Y, blob1_X, blob1_Y):
	distance = math.sqrt((math.pow(player1_X - blob1_X, 2) + math.pow(player1_Y - blob1_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player2_and_blob1(player2_X, player2_Y, blob1_X, blob1_Y):
	distance = math.sqrt((math.pow(player2_X - blob1_X, 2) + math.pow(player2_Y - blob1_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player1_and_blob2(player1_X, player1_Y, blob2_X, blob2_Y):
	distance = math.sqrt((math.pow(player1_X - blob2_X, 2) + math.pow(player1_Y - blob2_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player2_and_blob2(player2_X, player2_Y, blob2_X, blob2_Y):
	distance = math.sqrt((math.pow(player2_X - blob2_X, 2) + math.pow(player2_Y - blob2_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player1_and_blob3(player1_X, player1_Y, blob3_X, blob3_Y):
	distance = math.sqrt((math.pow(player1_X - blob3_X, 2) + math.pow(player1_Y - blob3_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player2_and_blob3(player2_X, player2_Y, blob3_X, blob3_Y):
	distance = math.sqrt((math.pow(player2_X - blob3_X, 2) + math.pow(player2_Y - blob3_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player1_and_blob4(player1_X, player1_Y, blob4_X, blob4_Y):
	distance = math.sqrt((math.pow(player1_X - blob4_X, 2) + math.pow(player1_Y - blob4_Y, 2)))
	if distance < 27:
		return True
	else:
		return False


def isCollsion_between_player2_and_blob4(player2_X, player2_Y, blob4_X, blob4_Y):
	distance = math.sqrt((math.pow(player2_X - blob4_X, 2) + math.pow(player2_Y - blob4_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player1_and_blob5(player1_X, player1_Y, blob5_X, blob5_Y):
	distance = math.sqrt((math.pow(player1_X - blob5_X, 2) + math.pow(player1_Y - blob5_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

def isCollsion_between_player2_and_blob5(player2_X, player2_Y, blob5_X, blob5_Y):
	distance = math.sqrt((math.pow(player2_X - blob5_X, 2) + math.pow(player2_Y - blob5_Y, 2)))
	if distance < 27:
		return True
	else:
		return False

#Main Game Loop 
running = True 
while running:
	#Fill the screen 
	screen.fill((WHITE))

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_d:
				player1_X_change = 1

			if event.key == pygame.K_a:
				player1_X_change = -1

			if event.key == pygame.K_w:
				player1_Y_change = -1

			if event.key == pygame.K_s:
				player1_Y_change = 1

			if event.key == pygame.K_LEFT:
				player2_X_change = -1

			if event.key == pygame.K_RIGHT:
				player2_X_change = 1

			if event.key == pygame.K_UP:
				player2_Y_change = -1

			if event.key == pygame.K_DOWN:
				player2_Y_change = 1

		if event.type == pygame.KEYUP:
			player1_X_change = 0
			player1_Y_change = 0
			player2_X_change = 0
			player2_Y_change = 0

	#Make the first player
	player1 = pygame.draw.circle(screen, (RED), (player1_X, player1_Y), player1_radius)

	#Make the second player
	player2 = pygame.draw.circle(screen, (BLUE), (player2_X, player2_Y), player2_radius)

	#Make the blob
	blob1 = pygame.draw.circle(screen, (GREEN), (blob1_X, blob1_Y), blob1_radius)
	blob2 = pygame.draw.circle(screen, (GREEN), (blob2_X, blob2_Y), blob2_radius)
	blob3 = pygame.draw.circle(screen, (GREEN), (blob3_X, blob3_Y), blob3_radius)
	blob4 = pygame.draw.circle(screen, (GREEN), (blob4_X, blob4_Y), blob4_radius)
	blob5 = pygame.draw.circle(screen, (GREEN), (blob5_X, blob5_Y), blob5_radius)

	#Collisions
	collision_1 = isCollision_between_players(player1_X, player1_Y, player2_X, player2_Y)
	if collision_1:
		break

	collision_2 = isCollsion_between_player1_and_blob1(player1_X, player1_Y, blob1_X, blob1_Y)
	if collision_2:
		player1_radius += 3
		blob1_X = random.randint(5, 795)
		blob1_Y = random.randint(5, 595)
		player1_score_value += 1

	collision_3 = isCollsion_between_player2_and_blob1(player2_X, player2_Y, blob1_X, blob1_Y)
	if collision_3:
		blob1_X = random.randint(5, 795)
		blob1_Y = random.randint(5, 595)
		player2_radius += 3
		player2_score_value += 1

	collision_4 = isCollsion_between_player1_and_blob2(player1_X, player1_Y, blob2_X, blob2_Y)
	if collision_4:
		player1_radius += 3
		blob2_X = random.randint(5, 795)
		blob2_Y = random.randint(5, 595)
		player1_score_value += 1

	collision_5 = isCollsion_between_player2_and_blob2(player2_X, player2_Y, blob2_X, blob2_Y)
	if collision_5:
		player2_radius += 3
		blob2_X = random.randint(5, 795)
		blob2_Y = random.randint(5, 595)
		player2_score_value += 1

	collision_6 = isCollsion_between_player1_and_blob3(player1_X, player1_Y, blob3_X, blob3_Y)
	if collision_6:
		player1_radius += 3
		blob3_X = random.randint(5, 795)
		blob3_Y = random.randint(5, 595)
		player1_score_value += 1

	collision_7 = isCollsion_between_player2_and_blob3(player2_X, player2_Y, blob3_X, blob3_Y)
	if collision_7:
		player2_radius += 3
		blob3_X = random.randint(5, 795)
		blob3_Y = random.randint(5, 595)
		player2_score_value += 1

	collision_8 = isCollsion_between_player1_and_blob4(player1_X, player1_Y, blob4_X, blob4_Y)
	if collision_8:
		player1_radius += 3
		blob4_X = random.randint(5, 795)
		blob4_Y = random.randint(5, 595)
		player1_score_value += 1

	collision_9 = isCollsion_between_player2_and_blob4(player2_X, player2_Y, blob4_X, blob4_Y)
	if collision_9:
		player2_radius += 3
		blob4_X = random.randint(5, 795)
		blob4_Y = random.randint(5, 595)
		player2_score_value += 1

	collision_10 = isCollsion_between_player1_and_blob5(player1_X, player1_Y, blob5_X, blob5_Y)
	if collision_10:
		player1_radius += 3
		blob5_X = random.randint(5, 795)
		blob5_Y = random.randint(5, 595)
		player1_score_value += 1

	collision_11 = isCollsion_between_player2_and_blob5(player2_X, player2_Y, blob5_X, blob5_Y)
	if collision_11:
		player2_radius += 3
		blob5_X = random.randint(5, 795)
		blob5_Y = random.randint(5, 595)
		player2_score_value += 1
		
	#Border Checking
	if player1_X < 20:
		player1_X = 20

	if player1_Y < 20:
		player1_Y = 20

	if player1_X > 780:
		player1_X = 780

	if player1_Y > 580:
		player1_Y = 580

	if player2_X < 20:
		player2_X = 20

	if player2_Y < 20:
		player2_Y = 20

	if player2_X > 780:
		player2_X = 780

	if player2_Y > 580:
		player2_Y = 580

	#Update the screen 
	player1_Y += player1_Y_change
	player1_X += player1_X_change
	player2_X += player2_X_change
	player2_Y += player2_Y_change
	show_score(textX, textY)
	show_score_2(textX_2, textY_2)
	pygame.display.update()